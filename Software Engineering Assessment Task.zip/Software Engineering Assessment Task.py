#In order to randomly select elements from the dictionary, we need to import the random module
import random

#Welcome message
print("Welcome")
print("This program will test you and improve your knowledge of the Periodic Table of Elements.")
#Asks the user to if they want to start or exit
start = input("Are you ready to start? (yes/no): ").lower()
#If the user types "no" or any other input, the program will end.
if "yes" not in start:
    print("Goodbye.")
    print("Come back when you are ready.")
    exit()
#If the user types "yes" the program will continue and will display the instructions.
if "yes" in start: 
    print("Great! Let's get started.")
    print("You will be given a choice of three categories to test your knowledge of the Periodic Table of Elements.")
    print("(1) Guess the element symbol")
    print("(2) Guess the element name") 
    print("(3) Guess the group of the element")
    print("You will be asked to answer 20 questions in each category.")
    print("Type 'exit' at any time to end the quiz.")
    print("Good luck!")

#Periodic Table elements in a dictionary using the element name as the key and the element symbol as the value.
periodic_table = {"Hydrogen": "H", "Helium": "He", "Lithium": "Li", "Beryllium": "Be", "Boron": "B", "Carbon": "C", "Nitrogen": "N", 
    "Oxygen": "O", "Fluorine": "F", "Neon": "Ne", "Sodium": "Na", "Magnesium": "Mg", "Aluminum": "Al", "Silicon": "Si",
    "Phosphorus": "P", "Sulfur": "S", "Chlorine": "Cl", "Argon": "Ar", "Potassium": "K", "Calcium": "Ca", "Scandium": "Sc",
    "Titanium": "Ti", "Vanadium": "V", "Chromium": "Cr", "Manganese": "Mn", "Iron": "Fe", "Cobalt": "Co", "Nickel": "Ni",
    "Copper": "Cu", "Zinc": "Zn", "Gallium": "Ga", "Germanium": "Ge", "Arsenic": "As", "Selenium": "Se", "Bromine": "Br",
    "Krypton": "Kr", "Rubidium": "Rb", "Strontium": "Sr", "Yttrium": "Y", "Zirconium": "Zr", "Niobium": "Nb", 
    "Molybdenum": "Mo", "Technetium": "Tc", "Ruthenium": "Ru", "Rhodium": "Rh", "Palladium": "Pd", "Silver": "Ag",
    "Cadmium": "Cd", "Indium": "In", "Tin": "Sn", "Antimony": "Sb", "Tellurium": "Te", "Iodine": "I", "Xenon": "Xe",
    "Cesium": "Cs", "Barium": "Ba", "Lanthanum": "La", "Cerium": "Ce", "Praseodymium": "Pr", "Neodymium": "Nd",
    "Promethium": "Pm", "Samarium": "Sm", "Europium": "Eu", "Gadolinium": "Gd", "Terbium": "Tb", "Dysprosium": "Dy",
    "Holmium": "Ho", "Erbium": "Er", "Thulium": "Tm", "Ytterbium": "Yb", "Lutetium": "Lu", "Hafnium": "Hf",
    "Tantalum": "Ta", "Tungsten": "W", "Rhenium": "Re", "Osmium": "Os", "Iridium": "Ir", "Platinum": "Pt", "Gold": "Au",
    "Mercury": "Hg", "Thallium": "Tl", "Lead": "Pb", "Bismuth": "Bi", "Polonium": "Po", "Astatine": "At", "Radon": "Rn",
    "Francium": "Fr", "Radium": "Ra", "Actinium": "Ac", "Thorium": "Th", "Protactinium": "Pa", "Uranium": "U",
    "Neptunium": "Np", "Plutonium": "Pu", "Americium": "Am", "Curium": "Cm", "Berkelium": "Bk", "Californium": "Cf",
    "Einsteinium": "Es", "Fermium": "Fm", "Mendelevium": "Md", "Nobelium": "No", "Lawrencium": "Lr", "Rutherfordium": "Rf",
    "Dubnium": "Db", "Seaborgium": "Sg", "Bohrium": "Bh", "Hassium": "Hs", "Meitnerium": "Mt", "Darmstadtium": "Ds",
    "Roentgenium": "Rg", "Copernicium": "Cn", "Nihonium": "Nh", "Flerovium": "Fl", "Moscovium": "Mc", "Livermorium": "Lv",
    "Tennessine": "Ts", "Oganesson": "Og"}

#Organizes the elements into their respective groups using a list within a dictionary.
#The key is the group name the and group number, and the value is a list of elements in that group. 
periodic_table_groups = {
    "Group 1 - Alkali Metals": ["Lithium/Li", "Sodium/Na", "Potassium/K", "Rubidium/Rb", "Cesium/Cs", "Francium/Fr"],
    "Group 2 - Alkaline Earth Metals": ["Beryllium/Be", "Magnesium/Mg", "Calcium/Ca", "Strontium/Sr", "Barium/Ba", "Radium/Ra"],
    "Group 3 - Scandium Group": ["Scandium/Sc", "Yttrium/Y", "Lanthanum/La", "Actinium/Ac"],
    "Group 4 - Titanium Group": ["Titanium/Ti", "Zirconium/Zr", "Hafnium/Hf", "Rutherfordium/Rf"],
    "Group 5 - Vanadium Group": ["Vanadium/V", "Niobium/Nb", "Tantalum/Ta", "Dubnium/Db"],
    "Group 6 - Chromium Group": ["Chromium/Cr", "Molybdenum/Mo", "Tungsten/W", "Seaborgium/Sg"],
    "Group 7 - Manganese Group": ["Manganese/Mn", "Technetium/Tc", "Rhenium/Re", "Bohrium/Bh"],
    "Group 8 - Iron Group": ["Iron/Fe", "Ruthenium/Ru", "Osmium/Os", "Hassium/Hs"],
    "Group 9 - Cobalt Group": ["Cobalt/Co", "Rhodium/Rh", "Iridium/Ir", "Meitnerium/Mt"],
    "Group 10 - Nickel Group": ["Nickel/Ni", "Palladium/Pd", "Platinum/Pt", "Darmstadtium/Ds"],
    "Group 11 - Copper Group": ["Copper/Cu", "Silver/Ag", "Gold/Au", "Roentgenium/Rg"],
    "Group 12 - Zinc Group": ["Zinc/Zn", "Cadmium/Cd", "Mercury/Hg", "Copernicium/Cn"],
    "Group 13 - Boron Group": ["Boron/B", "Aluminum/Al", "Gallium/Ga", "Indium/In", "Thallium/Tl"],
    "Group 14 - Carbon Group": ["Carbon/C", "Silicon/Si", "Germanium/Ge", "Tin/Sn", "Lead/Pb", "Flerovium/Fl"],
    "Group 15 - Nitrogen Group": ["Nitrogen/N", "Phosphorus/P", "Arsenic/As", "Antimony/Sb", "Bismuth/Bi", "Moscovium/Mc"],
    "Group 16 - Oxygen Group (Chalcogens)": ["Oxygen/O", "Sulfur/S", "Selenium/Se", "Tellurium/Te", "Polonium/Po", "Livermorium/Lv"],
    "Group 17 - Halogens": ["Fluorine/F", "Chlorine/Cl", "Bromine/Br", "Iodine/I", "Astatine/At", "Tennessine/Ts"],
    "Group 18 - Noble Gases": ["Helium/He", "Neon/Ne", "Argon/Ar", "Krypton/Kr", "Xenon/Xe", "Radon/Rn", "Oganesson/Og"],
    "Lanthanides": [
        "Lanthanum/La", "Cerium/Ce", "Praseodymium/Pr", "Neodymium/Nd", "Promethium/Pm",
        "Samarium/Sm", "Europium/Eu", "Gadolinium/Gd", "Terbium/Tb", "Dysprosium/Dy",
        "Holmium/Ho", "Erbium/Er", "Thulium/Tm", "Ytterbium/Yb", "Lutetium/Lu"
    ],
    "Actinides": [
        "Actinium/Ac", "Thorium/Th", "Protactinium/Pa", "Uranium/U", "Neptunium/Np",
        "Plutonium/Pu", "Americium/Am", "Curium/Cm", "Berkelium/Bk", "Californium/Cf",
        "Einsteinium/Es", "Fermium/Fm", "Mendelevium/Md", "Nobelium/No", "Lawrencium/Lr"
    ]
}


#Reverses the dictionary so that the element symbol is the key and the element name is the value
reversed_periodic_table = {v: k for k, v in periodic_table.items()}

#Asks the user to select a category 
category = input("Please select a category: ").lower()
#If the user types an invalid input, the program will ask the user to select a valid category
while category not in ["1", "2", "3"]:
   if category == "exit":
       print("Goodbye.")
       break
   print("Invalid input.")
   category = input("Please select a valid category: Guess the element symbol (1), Guess the element name (2), Guess group of the element (3): ")
   

#GUESS THE ELEMENT SYMBOL CATEGORY
if category == "1":
    print("You have selected Guess the element symbol")
    score = 0
    used_elements = [] #List to store elements that have already been asked
    #Asks the user to guess the symbol for 20 random elements
    #i starts from 1 and ends at 20
    for i in range(1, 21):
        while True:
            element = random.choice(list(periodic_table.keys()))
            if element not in used_elements: #Checks if the element has already been used
                used_elements.append(element) #Marks this element as used and adds it to the list
                break
        symbol = periodic_table[element]
        guess = input(f"{i}. What is the symbol for {element}" + "? ").capitalize()
        #If the user types "exit" the quiz will end
        if guess.lower() == "exit":
            break
        elif guess == symbol:
            print("Correct!")   
            score += 1
        else:
            print("Incorrect. The correct answer is,", symbol)
    print("You scored", score, "out of 20.")

#GUESS THE ELEMENT NAME CATEGORY
if category == "2":
    print("You have selected Guess the element name")
    score = 0
    used_symbols = [] #List to store symbols that have already been asked
    #Asks the user to guess the element name for 20 random elements.
    #i starts from 1 and ends at 20
    for i in range(1,21):
        while True:
            element = random.choice(list(reversed_periodic_table.keys()))
            if element not in used_symbols: #Checks if the symbol has already been used
                used_symbols.append(element) #Mark this symbol as used and adds it to the list
                break
        element_name = reversed_periodic_table[element]
        guess = input(f"{i}. What is the name for the symbol {element}" + "? ").capitalize()
        #If the user types "exit" the quiz will end
        if guess.lower() == "exit":
                break
        elif guess == element_name: 
            print("Correct!")
            score += 1
        else:
            print("Incorrect. The correct answer is", element_name)
    print("You scored", score, "out of 20.")

#GUESS THE GROUP OF THE ELEMENT CATEGORY
if category == "3":
    print("You have selected Guess the group of the element")
    score = 0
    used_elements = [] #List to store elements that have already been asked
    #Asks the user to guess the group of the element for 20 random elements.
    #i starts from 1 and ends at 20
    for i in range(1,21):
        while True:
            group = random.choice(list(periodic_table_groups.keys()))
            element = random.choice(periodic_table_groups[group])
            if element not in used_elements: #Checks if the element has already been used
                used_elements.append(element) #Mark this element as used and adds it to the list
                break
        guess = input(f"{i}. What group does the element {element} belong to? ").capitalize()
        #If the user types "exit" the quiz will end
        if guess.lower() == "exit":
            break
        #If the user types the group name without the word "Group" or the group number, the program will still accept it as correct
        elif guess.lower().replace("Group", "").strip() == group.lower().split(" ")[1] or guess.lower() in group.lower():
            print("Correct!")
            score += 1
        else:
            print("Incorrect. The correct answer is", group)
    print("You scored", score, "out of 20.")